import cv2
import pytesseract
import os
from pyzbar.pyzbar import decode


# Make one method to decode the barcode
def BarcodeReader(image):
    data = ''
    img = cv2.imread(image)
    detectedBarcodes = decode(img)
    
    if not detectedBarcodes:
        print("Barcode Not Detected or your barcode is blank/corrupted!")
    else:
        for barcode in detectedBarcodes:
            (x, y, w, h) = barcode.rect
            cv2.rectangle(img, (x-10, y-10),
						(x + w+10, y + h+10),
						(255, 0, 0), 2)
            
            if barcode.data!="":
                # print(barcode.data)
                # print(barcode.type)
                data = data + str(barcode.data.decode("utf-8")) + "|"
				
	#Display the image
	# cv2.imshow("Image", img)
	# cv2.waitKey(0)
	# cv2.destroyAllWindows()
    return data


pytesseract.pytesseract.tesseract_cmd = 'A:/New folder/tesseract.exe'
# img = cv2.imread("5000012880651.tif")
# img = cv2.imread("5001402615501.tif")
# img = cv2.imread("5007622338226.tif")
# img = cv2.imread("5014612711367.tif")


# ====================================================================
# ====================================================================
# Get the list of all files and directories
# path = "C:/Users/amitk/Desktop/Image recognition/New folder"
path = "C:/Users/amitk/Desktop/University-answer-booklet-eval-dash/New folder/Test data"
dir_list = os.listdir(path)
 
f = open("myfile.txt", "w")
f.close()

counter = 1
for x in dir_list:
    if x.endswith(".tif"):
        # Prints only text file present in My Folder
        # print('======================================================================')
        # print('======================================================================')
        # print(x)
# =====================================================================
# ====================================================================
        img = cv2.imread(path+"/"+x)
        height, width = img.shape[0:2]

        # print('height >>> ',height)
        # print('width >>> ',width)

        startRow = int(height * 0.10)
        startCol = int(width * 0.10)
        endRow = int(height * 0.90)
        endCol = int(width * 0.40)

        # print('startRow >>> ',startRow)
        # print('startCol >>> ',startCol)
        # print('endRow >>> ',endRow)
        # print('endCol >>> ',endCol)


        croppedImage = img[startRow:endRow, startCol:endCol]


        # cv2.imshow("original",img)

        # cropped_image = img[40:460, 60:460]
        # cropped_image = img[41:123, 191:203]

        text = pytesseract.image_to_string(img)
        # print(text)

        data = [int(s) for s in text.split() if s.isdigit() and len(s)>=6]
        # print(data)
        # ################################################################################################################
        image= path+"/"+x
        y = BarcodeReader(image)
        str_list = list(filter(None, y.split('|')))
        # print('fial data >>> ',str_list)
        # ################################################################################################################
        f = open("myfile.txt", "a")
        # writeData = 'Image : ',x," | Answer booklet no : ",data
        if(len(str_list) > 1):
            writeData = f"Image {counter} :- {str(x)} \t\t\t\t\t\t Answer booklet no : {str([str_list[1]])}  \t\t Barcode no : {str([str_list[0]])}   \t\t Student Roll no : {'-'}\n\n"
        else:
            try:
                if(len(data) > 0):
                    writeData = f"Image {counter} :- {str(x)} \t\t\t\t\t\t Answer booklet no : {str(data)}  \t\t Barcode no : {str([str_list[1]])}   \t\t Student Roll no : {'-'}\n\n"
                else:
                    writeData = f"Image {counter} :- {str(x)} \t\t\t\t\t\t Answer booklet no : {str(data)}  \t\t\t\t Barcode no : {str([str_list[1]])}   \t\t Student Roll no : {'-'}\n\n"
            except:
                writeData = f"Image {counter} :- {'-'} \t\t\t\t\t\t Answer booklet no : {'-'}  \t\t\t\t Barcode no : {'-'}   \t\t Student Roll no : {'-'}\n\n"


        f.write(writeData)
        f.close()
        # print('======================================================================')
        # print('======================================================================')
        # print('======================================================================')

        counter = counter + 1

        # cv2.imshow("original",cropped_image)
        # cv2.waitKey(0)
